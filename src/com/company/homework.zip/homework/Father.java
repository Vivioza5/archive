package com.company.lesson13.homework;

public class Father {
    Human father;

    public Human getFather() {
        return father;
    }

    public void setFather(Human father) {
        this.father = father;
    }
    public Father(Human human){
        this.father=human;
    }

    @Override
    public String toString() {
        return "Father{" +
                "father=" + father +
                '}';
    }
}
