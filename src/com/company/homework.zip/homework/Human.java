package com.company.lesson13.homework;

public class Human {
    String name;
    boolean male;
    int age;
    Human mother;
    Human father;
//запутался забыл или просто не видел как можно в конструкторе чтобы булевое значение вводить мужчина или женщина вместо  true, false
//    как обычно все гениальное просто!)) создал метод отдельно, после чего просто в toString задал булевое віражение и оно возвращает женщина или мужчина
    /*String   maleHuman (Human human){
    boolean male=this.man;
    return (male) ? "man":"woman";
}*/

//    но остался вопрос если задаем на ввывод дедушек или бабушек у них нет родителей, віводит nullexeption, как это обходить?


    public void setMother(Human mother) {
        this.mother = mother;
    }

    public Human getMother() {
        return mother;
    }

    public Human(String name, boolean male, int age) {
        this.name = name;
        this.male = male;
        this.age = age;
    }


void nameFather(){
    System.out.println(father.name);
}
    public Human getFather() {
        return father;
    }

    public void setFather(Human father) {
        this.father = father;
    }

    @Override
    public String toString() {
        return "{ name:" + name +
                ", male:" + ((male) ? "man":"woman") +
                ", age:" + age +", father: "+father.name+ ", mother: "+mother.name+
                " }";

    }
}
