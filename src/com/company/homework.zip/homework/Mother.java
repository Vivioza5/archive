package com.company.lesson13.homework;

public class Mother {
    Human mother;

    public void setMother(Human mother) {
        this.mother = mother;
    }

    public Human getMother() {
        return mother;
    }
    public Mother(Human human){
        this.mother=human;
    }
     void showMother(){
         System.out.println(this.mother);
    }

    @Override
    public String toString() {
        return "Mother{" +
                "mother=" + mother +
                '}';
    }
}
