package com.company.lesson13.homework;
/*
Создай класс Human с полями имя(String), пол(boolean), возраст(int), отец(Human), мать(Human).
        Создайте объекты и заполните их так, чтобы получилось: Два дедушки(Ivan,Igor), две бабушки(Olga,Lena), отец(Vasya), мать(Irina), трое детей(anna,Oleg,Yana).
        Вывести объекты на экран.
*/
public class Test {
    public static void main(String[] args) {

        Human ivan=new Human("Ivan", true,50);
        Human igor=new Human("Igor", true,60);
        Human olga=new Human("Olga", false,55);
        Human elena=new Human("Elena", false,55);
        Human vasya=new Human("Vasya", true,35);
        Human irina=new Human("Irina", false,35);
        Human oleg=new Human("Oleg", true,15);
        Human yana=new Human("Irina", false,13);
        Human anya= new Human("Anya",false,18);
        anya.setMother(irina);
        anya.setFather(vasya);

        yana.setMother(irina);
        yana.setFather(vasya);

        oleg.setMother(irina);
        oleg.setFather(vasya);

        vasya.setMother(olga);
        irina.setFather(ivan);

        irina.setMother(elena);
        irina.setFather(igor);


        System.out.print(anya);



    }
}
